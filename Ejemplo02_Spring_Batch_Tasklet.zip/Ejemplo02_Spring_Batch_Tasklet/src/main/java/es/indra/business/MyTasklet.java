package es.indra.business;

import java.util.Map;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Service;

// Un tasklet se utiliza cuando el proceso a ejecutar con Spring Batch
// es tan sencillo que no se necesita: ItemReader, ItemWriter, ItemProcessor

@Service
public class MyTasklet implements Tasklet{

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		// Recuperar los parametros del job
		Map<String, Object> parametros = chunkContext.getStepContext().getJobParameters();
		
		System.out.println(parametros.get("prueba"));
		System.out.println(parametros.get("time"));
		
		System.out.println("Ejecutando el tasklet");
		return RepeatStatus.FINISHED;
	}

}
