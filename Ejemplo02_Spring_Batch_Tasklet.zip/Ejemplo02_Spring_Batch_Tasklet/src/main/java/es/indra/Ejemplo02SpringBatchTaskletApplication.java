package es.indra;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo02SpringBatchTaskletApplication implements CommandLineRunner{
	
	@Autowired
	private Job job;
	
	@Autowired
	private JobLauncher jobLauncher;

	// En los proyectos con Spring Boot el metodo main esta dedicado
	// exclusivamente a levantar el contexto de Spring
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo02SpringBatchTaskletApplication.class, args);
	}

	// Este metodo se ejecuta de forma automatica a continuacion del metodo main
	@Override
	public void run(String... args) throws Exception {
		// Crear parametros del Job
		JobParameters jobParameters = new JobParametersBuilder()
				.addString("prueba", "Esto es un parametro del job")
				.addLong("time", System.currentTimeMillis())
				.toJobParameters();
		
		// Se los asignamos al job
		// Lo lanzamos con el jobLauncher
		JobExecution jobExecution = jobLauncher.run(job, jobParameters);
		
		System.out.println(jobExecution);
		System.out.println("Status: " + jobExecution.getStatus());
		System.out.println("Exit Status: " + jobExecution.getExitStatus());
		System.out.println("Hora inicio: " + jobExecution.getStartTime());
		System.out.println("Hora fin: " + jobExecution.getEndTime());
		
	}

}






