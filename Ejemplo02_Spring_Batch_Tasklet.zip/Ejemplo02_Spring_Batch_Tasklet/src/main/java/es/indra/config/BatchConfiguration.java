package es.indra.config;

// Ctrl + shift + o
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import es.indra.business.MyTasklet;

@Configuration
public class BatchConfiguration {
	
	@Autowired  // Inyectar un bean de tipo JobRepository
	private JobRepository jobRepository;
	
	@Autowired
	private PlatformTransactionManager txManager;
	
	
	@Autowired
	private MyTasklet myTasklet;
	
	@Bean   // convierte el objeto Java que retorna el metodo en un bean de Spring
	public Job job() {
		return new JobBuilder("job1", jobRepository)
				.start(step())
				.build();
	}
	
	@Bean
	public Step step() {
		return new StepBuilder("step1", jobRepository)
				.tasklet(myTasklet, txManager)
				.build();
		
		/*
		return new StepBuilder("step1", jobRepository)
				.tasklet((contribution, chunkContext) -> {
					System.out.println("Ejecutando el tasklet con lambda");
					return RepeatStatus.FINISHED;
				}, txManager)
				.build();
		*/
	}

}












