package es.indra.config;

// Ctrl + shift + o
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.MultiResourceItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.builder.MultiResourceItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.xml.StaxEventItemReader;
import org.springframework.batch.item.xml.StaxEventItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.WritableResource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.transaction.PlatformTransactionManager;

import es.indra.models.Producto;

@Configuration
public class BatchConfiguration {
	
	@Autowired  
	private JobRepository jobRepository;
	
	@Autowired
	private PlatformTransactionManager txManager;
	
	
	@Bean   
	public Job job() {
		return new JobBuilder("job1", jobRepository)
				.start(step())
				.build();
	}
	
	@Bean
	public Step step() {
		return new StepBuilder("step1", jobRepository)
				.<Producto, Producto>chunk(2, txManager)  // nº de registros que manejamos en cada bloque
				.reader(multiResourceItemReader())
				.writer(itemWriter())
				.build();
	}
	
	@Bean
//	public MultiResourceItemReader<Producto> multiResourceItemReader(
//			@Value("file:src/main/resources/input/data*.csv") Resource[] resources){
	
	// Otra forma de no recibir resources como parametro del metodo
	public MultiResourceItemReader<Producto> multiResourceItemReader(){	
		Resource[] resources = {
				new ClassPathResource("input/productos1.xml"),
				new ClassPathResource("input/productos2.xml"),
				new ClassPathResource("input/productos3.xml")
		};
		return new MultiResourceItemReaderBuilder<Producto>()
				.name("multiResourceItemReader")
				.resources(resources)
				.delegate(itemReader())  // cada productox.xml se lo pasamos al itemReader
				.build();	
	}
	
	/*
	 * xml ---> objeto Java  (Unmarshall)
	 * objeto Java ---> xml  (Marshall)
	 * */
	
	@Bean
	public Jaxb2Marshaller marshaller() {
		// Este bean es quien se encarga de hacer las operaciones Marshall y Unmarshall
		// cada <producto> queremos es un Producto.class y viceversa
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setClassesToBeBound(Producto.class);  // Le indicamos la clase de los objetos a procesar
		return marshaller;
	}
		
	@Bean  
	public StaxEventItemReader<Producto> itemReader(){
		StaxEventItemReader<Producto> reader = new StaxEventItemReader<>();
		reader.setFragmentRootElementName("producto");
		reader.setUnmarshaller(marshaller());
		return reader;
	}
	
	@Bean
	public StaxEventItemWriter<Producto> itemWriter(){
		StaxEventItemWriter<Producto> writer = new StaxEventItemWriter<>();
		// No funciona con ClassPathResource
		writer.setResource(new FileSystemResource("src/main/resources/output/resultado_productos.xml"));
		writer.setMarshaller(marshaller() );
		writer.setRootTagName("productos");
		return writer;
	}
	

}
















