package es.indra.config;

// Ctrl + shift + o
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.MultiResourceItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.builder.MultiResourceItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.WritableResource;
import org.springframework.transaction.PlatformTransactionManager;

import es.indra.models.Producto;

@Configuration
public class BatchConfiguration {
	
	@Autowired  
	private JobRepository jobRepository;
	
	@Autowired
	private PlatformTransactionManager txManager;
	
	
	@Bean   
	public Job job() {
		return new JobBuilder("job1", jobRepository)
				.start(step())
				.build();
	}
	
	@Bean
	public Step step() {
		return new StepBuilder("step1", jobRepository)
				.<Producto, Producto>chunk(2, txManager)  // nº de registros que manejamos en cada bloque
				.reader(multiResourceItemReader(null))
				.writer(itemWriter(null))  // El resource del metodo se inyecta por DI
				.build();
	}
	
	@Bean
	public MultiResourceItemReader<Producto> multiResourceItemReader(
			@Value("file:src/main/resources/input/data*.csv") Resource[] resources){
		return new MultiResourceItemReaderBuilder<Producto>()
				.name("multiResourceItemReader")
				.resources(resources)
				.delegate(itemReader())  // cada datax.csv se lo pasamos al itemReader
				.build();	
	}
		
	@Bean  
	public FlatFileItemReader<Producto> itemReader(){
		return new FlatFileItemReaderBuilder<Producto>()
				.name("productoItemReader")
				.delimited()
				.names("id", "descripcion", "precio")
				.fieldSetMapper(new BeanWrapperFieldSetMapper<Producto>() {
					{
						setTargetType(Producto.class);
					}
				})
				.build();
	}
	
	@Bean
	public FlatFileItemWriter<Producto> itemWriter(
			@Value("file:src/main/resources/output/resultado.csv") WritableResource resource){
		return new FlatFileItemWriterBuilder<Producto>()
			.name("productoItemWriter")	
			.resource(resource)
			.delimited()
			.delimiter(" | ")
			.names("id", "descripcion", "precio")
			.build();
	}
	

}
















