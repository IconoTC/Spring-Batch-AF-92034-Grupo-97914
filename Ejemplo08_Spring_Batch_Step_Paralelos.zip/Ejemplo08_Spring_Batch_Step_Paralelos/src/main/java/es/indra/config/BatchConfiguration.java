package es.indra.config;

// Ctrl + shift + o
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.job.flow.support.SimpleFlow;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class BatchConfiguration {
	
	@Autowired  
	private JobRepository jobRepository;
	
	@Autowired
	private PlatformTransactionManager txManager;
	
		
	@Bean   
	public Job job() {
		return new JobBuilder("job1", jobRepository)
				.start(new FlowBuilder<SimpleFlow>("jobFlow")
						.split(taskExecutor())
						.add(flow1(), flow2(), flow3())
						.build())
				.end()
				.build();
	}
	
	@Bean
	public Step step1() {
		return new StepBuilder("step1", jobRepository)
				.tasklet((contribution, chuckContext) -> {
					System.out.println("Ejecutando step1");
					return RepeatStatus.FINISHED;
				}, txManager)
				.build();
	}
	
	@Bean
	public Step step2() {
		return new StepBuilder("step2", jobRepository)
				.tasklet((contribution, chuckContext) -> {
					System.out.println("Ejecutando step2");
					return RepeatStatus.FINISHED;
				}, txManager)
				.build();
	}
	
	@Bean
	public Step step3() {
		return new StepBuilder("step3", jobRepository)
				.tasklet((contribution, chuckContext) -> {
					System.out.println("Ejecutando step3");
					return RepeatStatus.FINISHED;
				}, txManager)
				.build();
	}
	
	@Bean
	public Flow flow1() {
		return new FlowBuilder<SimpleFlow>("flow1")
				.start(step1())
				.build();
	}
	
	@Bean
	public Flow flow2() {
		return new FlowBuilder<SimpleFlow>("flow2")
				.start(step2())
				.build();
	}
	
	@Bean
	public Flow flow3() {
		return new FlowBuilder<SimpleFlow>("flow3")
				.start(step3())
				.build();
	}
	
	// Este bean hace que trabajemos con 3 hilos
	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor simpleAsyncTaskExecutor = new SimpleAsyncTaskExecutor("task");
		simpleAsyncTaskExecutor.setConcurrencyLimit(3); // Limita a 3 hilos simultaneos
		return simpleAsyncTaskExecutor;
	}
	

	

}
















