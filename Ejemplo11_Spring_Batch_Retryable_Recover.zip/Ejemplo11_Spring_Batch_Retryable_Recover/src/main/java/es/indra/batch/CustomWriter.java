package es.indra.batch;

import java.util.List;

import org.springframework.batch.item.ItemWriter;

import es.indra.models.Producto;

public class CustomWriter implements ItemWriter<Producto>{

	@Override
	public void write(List<? extends Producto> items) throws Exception {
		System.out.println(items);
		
	}

}
