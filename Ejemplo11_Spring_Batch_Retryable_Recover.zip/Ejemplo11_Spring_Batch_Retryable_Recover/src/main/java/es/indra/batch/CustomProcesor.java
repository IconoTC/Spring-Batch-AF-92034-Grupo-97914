package es.indra.batch;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import es.indra.models.Producto;
import es.indra.utils.ProductoValidationService;

public class CustomProcesor implements ItemProcessor<Producto, String>{
	
	@Autowired
	private  ProductoValidationService service;

	@Override
	public String process(Producto producto) throws Exception {
		return service.validate(producto);
	}

}


