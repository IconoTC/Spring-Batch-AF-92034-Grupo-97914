package es.indra.batch;

import java.util.Arrays;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.support.ListItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.annotation.EnableRetry;

import es.indra.models.Producto;

@Configuration
@EnableBatchProcessing
@EnableRetry // es obligatorio
public class BatchConfiguration {
	
	@Autowired
	private JobBuilderFactory  jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private DataSource dataSource;
	
	@Bean
    public Job customerJob() {
        return jobBuilderFactory.get("productosJob")
                .start(step())
                .build();
    }
	
	@Bean
    public Step step() {
        return stepBuilderFactory.get("customerStep")
                .<Producto, String>chunk(2)
                .reader(reader())
                .processor(processor())
                .writer(writer())
                .build();
    }
	
	
	@Bean
	public ItemReader<Producto> reader() {
		List<Producto> productos = Arrays.asList(
	            new Producto(1, "Pantalla", 129.95),
	            new Producto(2, "Teclado", 29.50),
	            new Producto(3, "Raton", 12.75)
	    );

	    return new ListItemReader<>(productos);
	}
	
	@Bean
	public CustomProcesor processor() {
		return new CustomProcesor();
	}
	
	@Bean
	public ItemWriter<String> writer() {

	    return items -> {
	        for (String item : items) {
	            System.out.println("Resultado: " + item);
	        }
	    };
	}
	

}








