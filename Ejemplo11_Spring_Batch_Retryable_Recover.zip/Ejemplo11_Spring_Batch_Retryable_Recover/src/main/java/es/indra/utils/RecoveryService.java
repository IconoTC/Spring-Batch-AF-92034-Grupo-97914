package es.indra.utils;

import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import es.indra.models.Producto;

@Component
public class RecoveryService {
	
	@Retryable(value = {RuntimeException.class}, maxAttempts = 2)
	public void procesarDatos(Producto producto) throws RuntimeException{
		System.out.println(".......................");
	}
	
	
	@Recover
	public void recover(RuntimeException ex, Producto producto) {
		// Intentar recuperar cuando se agotan los reintentos
		System.out.println("*************************");
		System.out.println("Lo estamos intentando con " + producto);
		System.out.println("*************************");
	}

}
