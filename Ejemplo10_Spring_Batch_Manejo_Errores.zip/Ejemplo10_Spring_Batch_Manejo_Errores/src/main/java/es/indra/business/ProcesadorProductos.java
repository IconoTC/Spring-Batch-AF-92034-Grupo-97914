package es.indra.business;

import org.springframework.batch.item.ItemProcessor;

import es.indra.models.Producto;

public class ProcesadorProductos implements ItemProcessor<Producto, Producto>{

	@Override
	public Producto process(Producto producto) throws Exception {
		
		if (producto.getId() == 3) {
			throw new RuntimeException("ERROR EN EL PRODUCTO 3");
		}
		
		
		// Aplicamos un 10% de dto en el precio del producto
		// La descripcion la ponemos en mayusculas
		
		double nuevoPrecio = producto.getPrecio() * 0.9;
		String nuevaDescripcion = producto.getDescripcion().toUpperCase();	
		
		// Modifico el producto de entrada
		producto.setDescripcion(nuevaDescripcion);
		producto.setPrecio(nuevoPrecio);
		
		return producto;
	}

}
