package es.indra.business;

import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;

import es.indra.models.Producto;

public class CustomWriter implements ItemWriter<Producto>{

	@Override
	public void write(Chunk<? extends Producto> chunk) throws Exception {
		
		for (Producto producto : chunk) {
			System.out.println("Escribiendo producto: " + producto);
		}
		
	}

}
