package es.indra.listener;

import org.springframework.batch.core.ItemReadListener;

import es.indra.models.Producto;

public class CustomReaderListener implements ItemReadListener<Producto>{

	@Override
	public void beforeRead() {
		System.out.println(" ------ Iniciando la lectura");
	}

	@Override
	public void afterRead(Producto item) {
		System.out.println(" ------ Finalizando la lectura " + item);
	}

	@Override
	public void onReadError(Exception ex) {
		System.out.println("Error de lectura: " + ex.getMessage());
	}
	
	

}
