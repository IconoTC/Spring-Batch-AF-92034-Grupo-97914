package es.indra.listener;

import org.springframework.batch.core.ItemProcessListener;

import es.indra.models.Producto;

public class CustomProcessorListener implements ItemProcessListener<Producto, Producto>{

	@Override
	public void beforeProcess(Producto item) {
		System.out.println(" ------ Iniciando el procesador de productos");
	}

	@Override
	public void afterProcess(Producto item, Producto result) {
		System.out.println(" ------ Finalizado el procesador de productos");
		System.out.println("Producto entrada: " + item);
		System.out.println("Producto salida: " + result);
	}

	@Override
	public void onProcessError(Producto item, Exception e) {
		System.out.println("Error de en el proceso: " + e.getMessage());
	}

	
	
}
