package es.indra.listener;

import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.item.Chunk;

import es.indra.models.Producto;

public class CustomWriterListener implements ItemWriteListener<Producto>{

	@Override
	public void beforeWrite(Chunk<? extends Producto> items) {
		System.out.println(" ------ Iniciando la escritura");
	}

	@Override
	public void afterWrite(Chunk<? extends Producto> items) {
		System.out.println(" ------ Finalizando la lectura");
	}

	@Override
	public void onWriteError(Exception exception, Chunk<? extends Producto> items) {
		System.out.println("Error de escritura: " + exception.getMessage());
	}

	
	
}
