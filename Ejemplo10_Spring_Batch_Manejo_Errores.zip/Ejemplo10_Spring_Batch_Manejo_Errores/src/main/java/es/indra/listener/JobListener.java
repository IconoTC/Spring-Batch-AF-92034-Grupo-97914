package es.indra.listener;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;

public class JobListener extends JobExecutionListenerSupport{
	

	@Override
	public void beforeJob(JobExecution jobExecution) {
		System.out.println(" ------ Iniciando el job");
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		System.out.println(" ------ Finalizando el job");
	}

}
