package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo03SpringBatchReaderWriterProcessorApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo03SpringBatchReaderWriterProcessorApplication.class, args);
	}

}
