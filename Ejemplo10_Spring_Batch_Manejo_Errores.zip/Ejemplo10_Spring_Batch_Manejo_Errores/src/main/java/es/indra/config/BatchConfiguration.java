package es.indra.config;

// Ctrl + shift + o
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.batch.item.database.builder.JpaItemWriterBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import es.indra.business.CustomReader;
import es.indra.business.CustomWriter;
import es.indra.business.ProcesadorProductos;
import es.indra.listener.CustomProcessorListener;
import es.indra.listener.CustomReaderListener;
import es.indra.listener.CustomWriterListener;
import es.indra.listener.JobListener;
import es.indra.models.Producto;

@Configuration
public class BatchConfiguration {
	
	@Autowired  
	private JobRepository jobRepository;
	
	@Autowired
	private PlatformTransactionManager txManager;
	
	
	@Bean
	public JobListener jobListener() {
		return new JobListener();
	}
		
	@Bean   
	public Job job() {
		return new JobBuilder("job1", jobRepository)
				.listener(jobListener())
				.start(step())
				.build();
	}
	
	/*
	@Bean
	public Step step() {
		return new StepBuilder("step1", jobRepository)
				.<Producto, Producto>chunk(2, txManager)  // nº de registros que manejamos en cada bloque
				.reader(itemReader())
				.processor(itemProcesor())
				.writer(itemWriter())
				.listener(customReaderListener())
				.listener(customWriterListener())
				.listener(customProcessorListener())
				.build();
	}*/
	
	// Estrategia RETRY:
	/*
	@Bean
	public Step step() {
		return new StepBuilder("step1", jobRepository)
				.<Producto, Producto>chunk(2, txManager)  // nº de registros que manejamos en cada bloque
				.reader(itemReader())
				.processor(itemProcesor())
				.writer(itemWriter())
				.faultTolerant()  // Que hacer en caso de fallo: definimos la estrategia
				.retryLimit(2)  // intenta ejecutarlo 2 veces
				.retry(RuntimeException.class)  // Si la excepcion es de tipo RuntimeException
				.listener(customReaderListener())
				.listener(customWriterListener())
				.listener(customProcessorListener())
				.build();
	}*/
	
	// Estrategia SKIP:
	/*
	@Bean
	public Step step() {
		return new StepBuilder("step1", jobRepository)
				.<Producto, Producto>chunk(2, txManager)  // nº de registros que manejamos en cada bloque
				.reader(itemReader())
				.processor(itemProcesor())
				.writer(itemWriter())
				.faultTolerant()  // Que hacer en caso de fallo: definimos la estrategia
				.skipLimit(2)  // maximo 2 elementos omitidos
				.skip(RuntimeException.class)  // Si la excepcion es de tipo RuntimeException
				.noSkip(NullPointerException.class)  // Esta excepcion no se puede omitir
				.listener(customReaderListener())
				.listener(customWriterListener())
				.listener(customProcessorListener())
				.build();
	}*/
	
	// Estrategia RESTART:
	@Bean
	public Step step() {
		return new StepBuilder("step1", jobRepository)
				.<Producto, Producto>chunk(2, txManager)  // nº de registros que manejamos en cada bloque
				.reader(itemReader())
				.processor(itemProcesor())
				.writer(itemWriter())
				.faultTolerant()  // Que hacer en caso de fallo: definimos la estrategia
				.retryLimit(2)  // intenta ejecutarlo 2 veces
				.retry(RuntimeException.class)  // Si la excepcion es de tipo RuntimeException
				.allowStartIfComplete(true)  // Permite reinicio pero necesita estrategia: retray o skip
				.listener(customReaderListener())
				.listener(customWriterListener())
				.listener(customProcessorListener())
				.build();
	}
	
	
	@Bean
	public CustomProcessorListener customProcessorListener() {
		return new CustomProcessorListener();
	}
	
	@Bean
	public CustomWriterListener customWriterListener() {
		return new CustomWriterListener();
	}
	
	@Bean
	public CustomReaderListener customReaderListener() {
		return new CustomReaderListener();
	}
	
	
	@Bean  
	public CustomReader itemReader(){
		return new CustomReader();
	}
	
	@Bean
	public ProcesadorProductos itemProcesor() {
		return new ProcesadorProductos();
	}
	
	@Bean
	public CustomWriter itemWriter(){
		return new CustomWriter();
	}
	

}
















