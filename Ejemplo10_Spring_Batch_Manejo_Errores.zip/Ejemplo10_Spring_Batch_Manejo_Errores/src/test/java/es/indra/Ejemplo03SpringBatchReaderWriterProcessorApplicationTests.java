package es.indra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo03SpringBatchReaderWriterProcessorApplicationTests {

	@Test
	void contextLoads() {
	}

}
