package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo02SpringBatchTaskletApplication {
	
	
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo02SpringBatchTaskletApplication.class, args);
	}


}






