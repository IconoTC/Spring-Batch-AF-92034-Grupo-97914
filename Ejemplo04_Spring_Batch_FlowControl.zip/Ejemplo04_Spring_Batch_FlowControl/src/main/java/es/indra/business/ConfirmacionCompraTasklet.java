package es.indra.business;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Service;


@Service
public class ConfirmacionCompraTasklet implements Tasklet{

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		if (false) {
			contribution.setExitStatus(ExitStatus.FAILED);
			System.out.println("Ha ocurrido un error en la confirmacion de compra");
		} else {
			contribution.setExitStatus(ExitStatus.COMPLETED);
		}
		
		System.out.println("Ejecutando el proceso de Confirmacion de Compra con tasklet");
		return RepeatStatus.FINISHED;
	}

}
