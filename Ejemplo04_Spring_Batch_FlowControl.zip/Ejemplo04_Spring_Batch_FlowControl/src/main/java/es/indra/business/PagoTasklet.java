package es.indra.business;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Service;


@Service
public class PagoTasklet implements Tasklet{

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		if (false) {
			contribution.setExitStatus(ExitStatus.FAILED);
			System.out.println("Ha ocurrido un error en el pago");
		} else {
			contribution.setExitStatus(ExitStatus.COMPLETED);
		}
		
		System.out.println("Ejecutando el proceso de Pago con tasklet");
		return RepeatStatus.FINISHED;
	}

}
