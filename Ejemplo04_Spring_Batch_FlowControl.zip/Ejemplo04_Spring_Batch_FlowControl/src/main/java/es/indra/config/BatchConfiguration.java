package es.indra.config;

// Ctrl + shift + o
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.transaction.PlatformTransactionManager;

import es.indra.business.ConfirmacionCompraTasklet;
import es.indra.business.ErrorTasklet;
import es.indra.business.LoginTasklet;
import es.indra.business.PagoTasklet;

@Configuration
public class BatchConfiguration {
	
	@Autowired  // Inyectar un bean de tipo JobRepository
	private JobRepository jobRepository;
	
	@Autowired
	private PlatformTransactionManager txManager;
	
	
	@Autowired
	private LoginTasklet loginTasklet;
	
	@Autowired
	private ConfirmacionCompraTasklet confirmacionCompraTasklet;
	
	@Autowired
	private PagoTasklet pagoTasklet;
	
	@Autowired
	private ErrorTasklet errorTasklet;
	

	@Bean
	public Step stepLogin() {
		return new StepBuilder("stepLogin", jobRepository)
				.tasklet(loginTasklet, txManager)
				.build();	
	}
	
	@Bean
	public Step stepConfirmacionCompra() {
		return new StepBuilder("stepConfirmacionCompra", jobRepository)
				.tasklet(confirmacionCompraTasklet, txManager)
				.build();	
	}

	@Bean
	public Step stepPago() {
		return new StepBuilder("stepPago", jobRepository)
				.tasklet(pagoTasklet, txManager)
				.build();	
	}
	
	@Bean
	public Step stepError() {
		return new StepBuilder("stepError", jobRepository)
				.tasklet(errorTasklet, txManager)
				.build();	
	}
	
	
	/*
	@Bean   
	public Job jobSecuencial() {
		return new JobBuilder("jobSecuencial", jobRepository)
				.start(stepLogin())
				.next(stepConfirmacionCompra())
				.next(stepPago())
				.build();
	}
	*/
	
	/*
	@Bean   
	public Job jobCondicional() {
		return new JobBuilder("jobCondicional", jobRepository)
				.start(stepLogin())
					.on("FAILED").end()
					.on("*").to(stepConfirmacionCompra())
				.from(stepConfirmacionCompra())
					.on("FAILED").end()
					.on("*").to(stepPago())
				.from(stepPago())
					.on("FAILED").end()
				.end()
				.build();
	}
	*/
	
	// Por defecto, en Spring, todos los beans son de tipo Singleton
	@Bean   
	//@Scope("prototype")
	public Job jobCondicionalConError() {
		return new JobBuilder("jobCondicionalConError", jobRepository)
				.start(stepLogin())
					.on("FAILED").to(stepError())
				.from(stepLogin())
					.on("*").to(stepConfirmacionCompra())
				.from(stepConfirmacionCompra())
					.on("FAILED").to(stepError())
				.from(stepConfirmacionCompra())
					.on("*").to(stepPago())
				.from(stepPago())
					.on("FAILED").to(stepError())
				.from(stepPago())
					.on("*").end()
				.from(stepError())
					.on("*").end()
				.end()
				.build();
	}
}












