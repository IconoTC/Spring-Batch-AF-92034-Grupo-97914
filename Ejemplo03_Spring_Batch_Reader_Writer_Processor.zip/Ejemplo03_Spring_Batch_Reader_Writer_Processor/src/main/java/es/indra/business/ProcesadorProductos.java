package es.indra.business;

import org.springframework.batch.item.ItemProcessor;

import es.indra.models.Producto;

public class ProcesadorProductos implements ItemProcessor<Producto, Producto>{

	@Override
	public Producto process(Producto producto) throws Exception {
		// Aplicamos un 10% de dto en el precio del producto
		// La descripcion la ponemos en mayusculas
		
		double nuevoPrecio = producto.getPrecio() * 0.9;
		String nuevaDescripcion = producto.getDescripcion().toUpperCase();
		
		// Creo un nuevo producto o modifico el producto de entrada
		Producto nuevoProducto = new Producto(producto.getId(), nuevaDescripcion, nuevoPrecio);
		
		System.out.println("Producto entrada: " + producto);
		System.out.println("Producto salida: " + nuevoProducto);
		
		return nuevoProducto;
	}

}
