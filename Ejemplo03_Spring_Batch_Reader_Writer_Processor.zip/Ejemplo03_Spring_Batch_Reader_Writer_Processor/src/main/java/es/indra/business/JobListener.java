package es.indra.business;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;

import es.indra.persistence.ProductosDAO;

public class JobListener extends JobExecutionListenerSupport{
	
	@Autowired
	private ProductosDAO dao;
	
	@Override
	public void beforeJob(JobExecution jobExecution) {
		System.out.println(" ------ Iniciando el job");
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		System.out.println(" ------ Finalizando el job");
		dao.findAll().stream().forEach(System.out::println);
	}

}
