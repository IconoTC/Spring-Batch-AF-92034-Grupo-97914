package es.indra.persistence;

import org.springframework.data.jpa.repository.JpaRepository;

import es.indra.models.Producto;

// Spring Boot cuando detecta que heredamos de xxxRepository genera un bean de Spring
public interface ProductosDAO extends JpaRepository<Producto, Integer>{

}
