package es.indra.config;

// Ctrl + shift + o
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.batch.item.database.builder.JpaItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.transaction.PlatformTransactionManager;

import es.indra.business.JobListener;
import es.indra.business.ProcesadorProductos;
import es.indra.models.Producto;
import jakarta.persistence.EntityManagerFactory;

@Configuration
public class BatchConfiguration {
	
	@Autowired  
	private JobRepository jobRepository;
	
	@Autowired
	private PlatformTransactionManager txManager;
	
	@Autowired
	private EntityManagerFactory emf;
	
	@Bean
	public JobListener jobListener() {
		return new JobListener();
	}
		
	@Bean   
	public Job job() {
		return new JobBuilder("job1", jobRepository)
				.listener(jobListener())
				.start(step())
				.build();
	}
	
	@Bean
	public Step step() {
		return new StepBuilder("step1", jobRepository)
				.<Producto, Producto>chunk(2, txManager)  // nº de registros que manejamos en cada bloque
				.reader(itemReader())
				.processor(itemProcesor())
				.writer(itemWriter())
				.build();
	}
	
	// ItemReader lee los productos
	@Bean  // el id o nombre del bean es el nombre del nombre
	public FlatFileItemReader<Producto> itemReader(){
		return new FlatFileItemReaderBuilder<Producto>()
				.name("productoItemReader")
				.resource(new ClassPathResource("data.csv"))
				.delimited()
				.names("id", "descripcion", "precio")
				.fieldSetMapper(new BeanWrapperFieldSetMapper<Producto>() {
					{
						setTargetType(Producto.class);
					}
				})
				.build();
	}
	
	
	// ItemProcesor procesa cada producto
	@Bean
	public ProcesadorProductos itemProcesor() {
		return new ProcesadorProductos();
	}
	
	// ItemWriter escribe los productos recibidos del ItemProcessor
	@Bean
	public JpaItemWriter<Producto> itemWriter(){
		return new JpaItemWriterBuilder<Producto>()
			.entityManagerFactory(emf)
			.build();
	}
	

}
















