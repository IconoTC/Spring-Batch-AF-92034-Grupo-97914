package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class Ejemplo01PlanificarTareaApplication {

	public static void main(String[] args) {
		// Levantar el contexto de Spring:
		// crea el contenedor con todos los beans que ha detectado
		SpringApplication.run(Ejemplo01PlanificarTareaApplication.class, args);
	}

}
