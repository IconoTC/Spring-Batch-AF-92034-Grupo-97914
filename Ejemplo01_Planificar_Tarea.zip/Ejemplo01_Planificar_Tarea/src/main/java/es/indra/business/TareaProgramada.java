package es.indra.business;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service  // Quiero un bean de esta clase
public class TareaProgramada {
	
	// Queremos que se ejecute cada 3 segundos
	@Scheduled(fixedRate = 3000)
	public void contenido() {
		System.out.println("Bienvenidos al curso de Spring Batch");
	}

}
