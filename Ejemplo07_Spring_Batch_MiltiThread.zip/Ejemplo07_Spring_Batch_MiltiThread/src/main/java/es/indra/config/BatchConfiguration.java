package es.indra.config;

import java.util.Arrays;
import java.util.List;

// Ctrl + shift + o
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.batch.item.database.builder.JpaItemWriterBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import es.indra.business.CustomReader;
import es.indra.business.CustomWriter;
import es.indra.models.Producto;

@Configuration
public class BatchConfiguration {
	
	@Autowired  
	private JobRepository jobRepository;
	
	@Autowired
	private PlatformTransactionManager txManager;
	
		
	@Bean   
	public Job job() {
		return new JobBuilder("job1", jobRepository)
				.flow(step())
				.end()
				.build();
	}
	
	@Bean
	public Step step() {
		return new StepBuilder("step1", jobRepository)
				.<Producto, Producto>chunk(1, txManager)  // nº de registros que manejamos en cada bloque
				.reader(itemReader())
				.writer(itemWriter())
				.taskExecutor(taskExecutor())
				.throttleLimit(2)  // limitar el numero de hilos a 3
				.build();
	}
	
	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor simpleAsyncTaskExecutor = new SimpleAsyncTaskExecutor("task");
		simpleAsyncTaskExecutor.setConcurrencyLimit(2); // Limita a 3 hilos simultaneos
		return simpleAsyncTaskExecutor;
	}
	

	@Bean  
	public CustomReader itemReader(){
		List<Producto> lista = Arrays.asList(
				new Producto(1, "Portatil", 1400),
				new Producto(2, "Raton", 45),
				new Producto(3, "Pantalla", 156),
				new Producto(4, "Disco externo", 120),
				new Producto(5, "Altavoces", 95));
		return new CustomReader(lista);
	}
	
	
	@Bean
	public CustomWriter itemWriter(){
		return new CustomWriter();
	}
	

}
















